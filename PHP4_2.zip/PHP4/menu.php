<a href="posts.php">Posts</a>
<br/>
<a href="profile.php">Profile</a>
<br/>
<a href="index.php">Logout</a>
