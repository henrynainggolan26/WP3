<?php
$availableTags = "ActionScript AppleScript BASIC ColdFusion";
	//$args = array('s' => 'keyword');
	$arrayAvailable = explode(" ", $availableTags);
	print_r($arrayAvailable); die();